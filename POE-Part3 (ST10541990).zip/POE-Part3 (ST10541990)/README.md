# Paws Rescue Centre | WEDE5020 PoE, Part 3

**Student Names:** Edwin Bresland Njoumessi Kamgang
**Student Number:** ST10541990
**Organisation:** Paws Rescue Centre (fictional)  
**Part:** 3, Functionality and SEO  
**Stack:** Semantic HTML5, external CSS, vanilla JavaScript, Leaflet and OpenStreetMap


## Project overview

A responsive five-page site for a fictional Johannesburg animal rescue centre. Visitors can learn about the organisation, search and sort sample adoptable-animal listings, open an accessible photo lightbox, locate two illustrative centres on an interactive map, and use validated enquiry/contact forms. Search, profile details, organisation locations, email and adoption figures are fictional examples. Replace them with approved client information before public use.

## Pages and features

- `index.html`: overview, calls to action, impact figures and photo gallery.
- `about.html`: organisation story, values and care gallery.
- `services.html`: data-driven adoptable animal search/filter/sort, lightbox gallery and interactive map.
- `enquiry.html`: accessible enquiry controls, inline validation and context-sensitive next-step response.
- `contact.html`: accessible general contact form and two-location interactive map.
- `css/style.css`: mobile-first responsive layout, visual states, reduced-motion support and accessible focus styles.
- `js/main.js`: navigation, listing renderer, filtering, sorting, lightbox controls, Leaflet map setup and form validation/response.
- `images/`: original local SVG illustrations with descriptive filenames and meaningful alternative text.
- `robots.txt`, `sitemap.xml`: crawler guidance and page discovery. Replace the example domain after deployment.


## Run and test locally

1. Extract the ZIP and open the project folder in VS Code.
2. Serve the folder with VS Code Live Server or another local static server. Avoid opening `file://` for map testing.
3. Test all five pages at desktop, tablet and mobile widths; check keyboard-only navigation and browser console errors.
4. Test no-results search, each animal filter/sort, lightbox controls, all required/invalid form fields, and mailto handoff.
5. The map requires internet access for Leaflet and OpenStreetMap tiles. All text, forms and location details remain available when map resources are unavailable.


## Changelog

### 2026-11-02 | Part 3 implementation
- Added data-driven animal profiles with live name/species/trait search, species filtering, alphabetical and age sorting, result counts, an empty state, and prefilled animal enquiry links.
- Added a keyboard-operable image lightbox with previous/next navigation, Escape-to-close, captions, responsive sizing and focus return.
- Added two interactive Leaflet maps with location pins, popups, location focus controls and OpenStreetMap attribution, plus a graceful external-library fallback.
- Added accessible enquiry and general contact forms with labels, appropriate input types, browser constraints, custom inline validation, first-invalid focus and live-region confirmation.
- Added tailored enquiry responses by adoption, fostering, volunteering and sponsorship intent. Added a `mailto:` contact handoff and explicitly disclosed its static-site limitation.
- Added unique page titles, descriptions and relevant keywords, social preview metadata, canonical URL placeholders, descriptive local SVG asset names/alt text, `robots.txt` and `sitemap.xml`.
- Added original local vector illustrations, responsive styles, visible keyboard focus, skip links and reduced-motion support.
- **Part 2 feedback received and addressed:** Marker feedback praised the web-development understanding, but noted that GitHub lacked detailed commits and a README, styling was inconsistent, and the stylesheet was not properly connected to the webpages. The continuation uses one external `css/style.css` linked by all five HTML pages; shared CSS variables, typography, spacing, navigation and reusable component styles establish a cohesive system. This README now documents project purpose, page features, setup/testing, deployment, references, and the change history. The repository itself was not provided, so GitHub commits cannot be created or represented as completed here; suggested commit messages are listed in the deployment workflow.

## References (Harvard style)

- Google Search Central (n.d.) *SEO Starter Guide*. Available at: https://developers.google.com/search/docs/fundamentals/seo-starter-guide (Accessed: 2 November 2026).
- Mozilla (n.d.) *Constraint validation*. MDN Web Docs. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Constraint_validation (Accessed: 2 November 2026).
- Mozilla (n.d.) *Using the HTML form validation APIs*. MDN Web Docs. Available at: https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Form_validation (Accessed: 2 November 2026).
- OpenStreetMap contributors (n.d.) *Copyright and license*. Available at: https://www.openstreetmap.org/copyright (Accessed: 2 November 2026).
- OpenStreetMap Foundation (n.d.) *Tile usage policy*. Available at: https://operations.osmfoundation.org/policies/tiles/ (Accessed: 2 November 2026).
- Leaflet (n.d.) *Leaflet: an open-source JavaScript library for mobile-friendly interactive maps*. Available at: https://leafletjs.com/ (Accessed: 2 November 2026).
- World Wide Web Consortium (W3C) (n.d.) *Web Content Accessibility Guidelines (WCAG) 2.2*. Available at: https://www.w3.org/TR/WCAG22/ (Accessed: 2 November 2026).
- OpenAI (2026) *ChatGPT* [large language model]. Assistance used to generate and review HTML, CSS, JavaScript, documentation and original SVG illustration concepts for this Part 3 submission. (Accessed: 2 November 2026). **Complete the institution’s AI disclosure annex and attach the required screenshot(s) of the actual AI interaction before submission.**


